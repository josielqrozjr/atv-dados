package fila;

import lista.ListaEncadeada;
import lista.Celula;

public class FilaEncadeada {
    private ListaEncadeada lista;

    public FilaEncadeada() {
        lista = new ListaEncadeada();
    }

    // Inserir o elemento no final da fila
    public void insere(int dado) {
        lista.insereUltimo(dado);
    }

    // Remover o elemento especificado no parâmetro
    public void remove(int valor) {
        Celula elemento = lista.buscaCelula(valor);
        if (elemento != null) {
            lista.remove(elemento);
            System.out.println("Elemento " + valor + " removido da fila.");
        } else {
            System.out.println("Elemento " + valor + " não encontrado na fila.");
        }
    }

    // Verificar se a fila está vazia
    public boolean vazia() {
        return lista.getPrimeiro() == null;
    }

    // Exibir todos os elementos da fila
    public void mostraFila() {
        System.out.print("Fila: ");
        lista.imprime();
    }
}
