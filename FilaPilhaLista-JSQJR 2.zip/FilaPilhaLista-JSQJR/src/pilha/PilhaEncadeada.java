package pilha;

import lista.ListaEncadeada;
import lista.Celula;

public class PilhaEncadeada {
    private ListaEncadeada lista;

    public PilhaEncadeada() {
        lista = new ListaEncadeada();
    }

    // Empilha o elemento no topo da pilha
    public void empilha(int dado) {
        lista.inserePrimeiro(dado);
    }

    // Desempilha o elemento do topo da pilha
    public int desempilha() {
        Celula removida = lista.removePrimeiro();
        if (removida != null) {
            return removida.getElemento();
        } else {
            return -1;
        }
    }

    // Retorna o elemento do topo da pilha sem removê-lo
    public int topo() {
        if (!vazia()) {
            return lista.getPrimeiro().getElemento();
        } else {
            return -1;
        }
    }

    // Verifica se a pilha está vazia
    public boolean vazia() {
        return lista.getPrimeiro() == null;
    }

    // Exibe todos os elementos da pilha
    public void mostraPilha() {
        System.out.print("Pilha: ");
        lista.imprime();
    }
}

